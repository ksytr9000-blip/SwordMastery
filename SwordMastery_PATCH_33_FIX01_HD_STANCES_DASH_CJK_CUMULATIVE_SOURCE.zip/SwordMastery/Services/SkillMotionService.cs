using System;
using HarmonyLib;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Tools;

namespace SwordMastery.Services;

// The visual pose never changes FarmerSprite or the farmer's movement permissions.
// Only the local farmer's drawing is replaced, for a few ticks, during a successful skill cast.
internal enum SkillMotion { Step, Slash, Flurry, Issen, Pinnacle, Footwork }

internal sealed class SkillMotionService
{
    private const int Cell = 128;
    private const int Frames = 8;
    private readonly Texture2D body;
    private readonly Texture2D shirt;
    private readonly Texture2D blade;
    private readonly Func<bool> posesEnabled;
    private readonly Func<bool> swordsEnabled;
    private static SkillMotionService? activeService;
    private Farmer? actor;
    private GameLocation? location;
    private StardewValley.Tool? initialTool;
    private SkillMotion motion;
    private int direction;
    private int remaining;
    private int duration;
    private bool drawHookInstalled;

    public SkillMotionService(IModHelper helper, IMonitor monitor, Func<bool> posesEnabled, Func<bool> swordsEnabled)
    {
        this.posesEnabled = posesEnabled;
        this.swordsEnabled = swordsEnabled;
        body = helper.ModContent.Load<Texture2D>("assets/motions/stance_body_hd.png");
        shirt = helper.ModContent.Load<Texture2D>("assets/motions/stance_shirt_hd.png");
        blade = helper.ModContent.Load<Texture2D>("assets/motions/stance_sword_hd.png");
        activeService = this;
        try
        {
            var drawMethod = AccessTools.Method(typeof(Farmer), "draw", new[] { typeof(SpriteBatch) });
            if (drawMethod is null)
                monitor.Log("Farmer.draw(SpriteBatch) not found; using visual draw fallback.", LogLevel.Warn);
            else
            {
                new Harmony("Prototype.SwordMastery.SkillMotion.PATCH33").Patch(
                    drawMethod, prefix: new HarmonyMethod(typeof(SkillMotionService), nameof(DrawPrefix)));
                drawHookInstalled = true;
            }
        }
        catch (Exception ex)
        {
            monitor.Log($"Full-body farmer draw patch unavailable; using fallback: {ex.Message}", LogLevel.Warn);
        }
    }

    private static bool DrawPrefix(Farmer __instance, SpriteBatch b)
    {
        if (activeService is null)
            return true;
        try { return !activeService.TryDraw(__instance, b); }
        catch { return true; } // Never make the player invisible on a graphics exception.
    }

    public void Play(Farmer player, SkillMotion skill, int hitCount = 1)
    {
        if (!posesEnabled() || Game1.activeClickableMenu is not null)
            return;
        if (player.UsingTool || Game1.eventUp)
            return;
        actor = player;
        location = Game1.currentLocation;
        initialTool = player.CurrentTool;
        motion = skill;
        direction = player.FacingDirection;
        duration = skill switch
        {
            SkillMotion.Flurry => Math.Max(20, hitCount * 9 + 6),
            SkillMotion.Pinnacle => Math.Max(20, hitCount * 8 + 6),
            SkillMotion.Step => 17,
            SkillMotion.Issen => 19,
            SkillMotion.Footwork => 15,
            _ => 18
        };
        remaining = duration;
    }

    public void Update()
    {
        if (remaining <= 0)
            return;
        if (actor is null || Game1.player != actor || Game1.currentLocation != location
            || Game1.activeClickableMenu is not null || Game1.eventUp || actor.CurrentTool != initialTool)
        {
            Reset();
            return;
        }
        remaining--;
        if (remaining == 0)
            Reset();
    }

    public void Reset()
    {
        remaining = duration = 0;
        actor = null;
        location = null;
        initialTool = null;
    }

    private bool TryDraw(Farmer farmer, SpriteBatch b)
    {
        if (actor != farmer || remaining <= 0 || location != Game1.currentLocation || !posesEnabled())
            return false;

        int passed = duration - remaining;
        int frame = Math.Min(Frames - 1, passed * Frames / Math.Max(1, duration));
        if (motion is SkillMotion.Flurry or SkillMotion.Pinnacle && duration > 35)
            frame = Math.Min(7, (passed / 4) % Frames);
        int group = (int)motion;
        var src = new Rectangle(frame * Cell, (group * 4 + direction) * Cell, Cell, Cell);
        Vector2 screen = Game1.GlobalToLocal(Game1.viewport, farmer.Position + new Vector2(-32f, -64f));
        float depth = Math.Clamp(farmer.GetBoundingBox().Bottom / 10000f, 0f, 1f);
        b.Draw(body, screen, src, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, depth);
        b.Draw(shirt, screen, src, farmer.GetShirtColor(), 0f, Vector2.Zero, 1f, SpriteEffects.None, depth + 0.000001f);
        if (swordsEnabled() && farmer.CurrentTool is MeleeWeapon)
            b.Draw(blade, screen, src, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, depth + 0.000002f);
        return true;
    }

    // Runs only if the per-farmer draw patch wasn't available.
    public void DrawFallback(SpriteBatch b)
    {
        if (!drawHookInstalled && actor is not null)
            TryDraw(actor, b);
    }
}
