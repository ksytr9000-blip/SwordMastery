using System.Reflection;
using System.Text.Json;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewValley;

namespace SwordMastery;

internal static class I18n
{
    private static readonly Dictionary<string, Dictionary<string, string>> Localizations = new();
    private static readonly Dictionary<string, SpriteFont> FontCache = new();
    private static Func<string> CurrentLanguage = () => "English";

    public static void Init(IModHelper helper, Func<string> currentLanguage)
    {
        CurrentLanguage = currentLanguage;
        Localizations["English"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","default.json"));
        Localizations["Korean"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","ko.json"));
        Localizations["Japanese"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","ja.json"));
        Localizations["Chinese"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","zh.json"));
    }

    // Game ships fonts for these languages even when the interface is English.
    // Load the explicitly locale-suffixed SpriteFonts without changing game language.
    public static SpriteFont SmallFont => GetFont(false);
    public static SpriteFont HeadingFont => GetFont(true);

    private static SpriteFont GetFont(bool heading)
    {
        string language = CurrentLanguage();
        string? suffix = language switch
        {
            "Japanese" => "ja-JP",
            "Chinese" => "zh-CN",
            "Korean" => "ko-KR",
            _ => null
        };
        if (suffix is null)
            return heading ? Game1.dialogueFont : Game1.smallFont;

        string assetName = (heading ? "Fonts/SpriteFont1." : "Fonts/SmallFont.") + suffix;
        if (FontCache.TryGetValue(assetName, out SpriteFont? cached))
            return cached;
        try
        {
            SpriteFont font = Game1.content.Load<SpriteFont>(assetName);
            FontCache[assetName] = font;
            return font;
        }
        catch
        {
            // Avoid crashing if a custom distribution has no CJK fonts.
            return heading ? Game1.dialogueFont : Game1.smallFont;
        }
    }

    private static Dictionary<string, string> LoadDictionary(string path)
    {
        try
        {
            return JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(path))
                ?? new Dictionary<string, string>();
        }
        catch { return new Dictionary<string, string>(); }
    }

    // In native game menus (including GMCM, item tooltips and quest journal),
    // use text supported by the current GAME font. The independent skill tree
    // uses GetUi and its own selected-language font instead.
    public static string Get(string key, object? tokens = null)
    {
        string chosen = CurrentLanguage();
        if (chosen == "Japanese" && LocalizedContentManager.CurrentLanguageCode != LocalizedContentManager.LanguageCode.ja)
            chosen = "English";
        if (chosen == "Chinese" && LocalizedContentManager.CurrentLanguageCode != LocalizedContentManager.LanguageCode.zh)
            chosen = "English";
        return Translate(chosen, key, tokens);
    }

    public static string GetUi(string key, object? tokens = null)
        => Translate(CurrentLanguage(), key, tokens);

    private static string Translate(string language, string key, object? tokens)
    {
        if (!Localizations.TryGetValue(language, out var selected))
            selected = Localizations["English"];
        if (!selected.TryGetValue(key, out string? value)
            && !Localizations["English"].TryGetValue(key, out value))
            return key;
        if (tokens is null)
            return value;
        foreach (PropertyInfo property in tokens.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
        {
            string token = "{{" + property.Name + "}}";
            value = value.Replace(token, property.GetValue(tokens)?.ToString() ?? "", StringComparison.Ordinal);
        }
        return value;
    }
}
