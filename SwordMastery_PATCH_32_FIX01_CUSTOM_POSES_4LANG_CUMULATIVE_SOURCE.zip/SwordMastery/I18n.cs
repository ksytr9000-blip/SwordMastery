using System.Reflection;
using System.Text.Json;
using StardewModdingAPI;

namespace SwordMastery;

internal static class I18n
{
    private static readonly Dictionary<string, Dictionary<string, string>> Localizations = new();
    private static Func<string> CurrentLanguage = () => "English";

    public static void Init(
        IModHelper helper,
        Func<string> currentLanguage
    )
    {
        CurrentLanguage = currentLanguage;

        Localizations["English"] = LoadDictionary(
            Path.Combine(helper.DirectoryPath, "i18n", "default.json")
        );

        Localizations["Korean"] = LoadDictionary(
            Path.Combine(helper.DirectoryPath, "i18n", "ko.json")
        );

        Localizations["Japanese"] = LoadDictionary(
            Path.Combine(helper.DirectoryPath, "i18n", "ja.json")
        );

        Localizations["Chinese"] = LoadDictionary(
            Path.Combine(helper.DirectoryPath, "i18n", "zh.json")
        );
    }

    private static Dictionary<string, string> LoadDictionary(string path)
    {
        try
        {
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                ?? new Dictionary<string, string>();
        }
        catch
        {
            return new Dictionary<string, string>();
        }
    }

    public static string Get(string key, object? tokens = null)
    {
        string selectedLanguage = CurrentLanguage();

        if (!Localizations.TryGetValue(selectedLanguage, out Dictionary<string, string>? selected))
            selected = Localizations["English"];

        if (!selected.TryGetValue(key, out string? value)
            && !Localizations["English"].TryGetValue(key, out value))
        {
            return key;
        }

        if (tokens is null)
            return value;

        foreach (PropertyInfo property in tokens.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
        {
            string token = "{{" + property.Name + "}}";
            string replacement = property.GetValue(tokens)?.ToString() ?? string.Empty;
            value = value.Replace(token, replacement, StringComparison.Ordinal);
        }

        return value;
    }
}
