using System.Reflection;
using System.Text.Json;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewValley;

namespace SwordMastery;

internal static class I18n
{
    private static readonly Dictionary<string, Dictionary<string, string>> Localizations = new();
    private static Func<string> CurrentLanguage = () => "English";
    private static LocalizedFontRenderer? fontRenderer;

    public static void Init(IModHelper helper, Func<string> currentLanguage)
    {
        CurrentLanguage=currentLanguage;
        Localizations["English"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","default.json"));
        Localizations["Korean"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","ko.json"));
        Localizations["Japanese"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","ja.json"));
        Localizations["Chinese"] = LoadDictionary(Path.Combine(helper.DirectoryPath,"i18n","zh.json"));
    }

    public static void SetFontRenderer(LocalizedFontRenderer renderer) => fontRenderer=renderer;
    public static bool NeedsIndependentCjkFont => CurrentLanguage() is "Japanese" or "Chinese";
    public static SpriteFont SmallFont => NeedsIndependentCjkFont
        ? fontRenderer?.Small ?? Game1.smallFont : Game1.smallFont;
    public static SpriteFont HeadingFont => NeedsIndependentCjkFont
        ? fontRenderer?.Heading ?? Game1.dialogueFont : Game1.dialogueFont;

    private static Dictionary<string, string> LoadDictionary(string path)
    {
        try
        {
            return JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(path))
                ?? new Dictionary<string, string>();
        }
        catch { return new Dictionary<string, string>(); }
    }

    // Translate every Sword Mastery field, even when the game language differs.
    // CjkTextService handles native rendering; no English substitution.
    public static string Get(string key, object? tokens = null)
        => Translate(CurrentLanguage(), key, tokens);

    public static string SelectedLanguage => CurrentLanguage();

    public static string GetUi(string key, object? tokens = null)
        => Translate(CurrentLanguage(), key, tokens);

    private static string Translate(string language, string key, object? tokens)
    {
        if (!Localizations.TryGetValue(language, out var selected))
            selected = Localizations["English"];
        if (!selected.TryGetValue(key, out string? value)
            && !Localizations["English"].TryGetValue(key, out value))
            return key;
        if (tokens is null)
            return value;
        foreach (PropertyInfo property in tokens.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
        {
            string token = "{{" + property.Name + "}}";
            value = value.Replace(token, property.GetValue(tokens)?.ToString() ?? "", StringComparison.Ordinal);
        }
        return value;
    }
}
